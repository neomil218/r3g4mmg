package com.app.g39.appg39;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Appg39ApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.app.g39.appg39;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Appg39Application {

	public static void main(String[] args) {
		SpringApplication.run(Appg39Application.class, args);
	}

}
